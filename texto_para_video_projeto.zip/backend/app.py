from flask import Flask, request, send_file
from gtts import gTTS
from moviepy.editor import ImageClip, AudioFileClip
from PIL import Image, ImageDraw
import os
from datetime import datetime

app = Flask(__name__)

@app.route("/api/gerar-video", methods=["POST"])
def gerar_video():
    data = request.get_json()
    texto = data.get("texto", "")

    if not texto.strip():
        return {"erro": "Texto vazio."}, 400

    try:
        # Criar áudio com gTTS
        audio_path = "audio.mp3"
        tts = gTTS(text=texto, lang="pt-br")
        tts.save(audio_path)

        # Criar imagem simples de fundo
        image_path = "fundo.jpg"
        if not os.path.exists(image_path):
            img = Image.new("RGB", (1280, 720), color=(70, 130, 180))
            d = ImageDraw.Draw(img)
            d.text((50, 50), "Texto para Vídeo", fill=(255, 255, 255))
            img.save(image_path)

        # Criar vídeo
        audio = AudioFileClip(audio_path)
        imagem = ImageClip(image_path).set_duration(audio.duration).set_audio(audio)
        imagem = imagem.resize(height=720)
        video_path = f"video_{datetime.now().timestamp()}.mp4"
        imagem.write_videofile(video_path, fps=24)

        return send_file(video_path, mimetype="video/mp4")

    except Exception as e:
        return {"erro": str(e)}, 500

if __name__ == "__main__":
    app.run(debug=True)