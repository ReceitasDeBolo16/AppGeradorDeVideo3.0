async function gerarVideo() {
  const texto = document.getElementById("inputText").value;
  const botao = document.querySelector("button");

  if (!texto.trim()) {
    alert("Digite um texto válido.");
    return;
  }

  botao.disabled = true;
  botao.textContent = "Gerando vídeo...";

  try {
    const response = await fetch("https://SEU-BACKEND-URL/api/gerar-video", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ texto })
    });

    if (!response.ok) throw new Error("Erro ao gerar vídeo.");

    const blob = await response.blob();
    const url = URL.createObjectURL(blob);

    const video = document.getElementById("videoPreview");
    video.src = url;
    video.style.display = "block";
  } catch (err) {
    alert("Erro: " + err.message);
  } finally {
    botao.disabled = false;
    botao.textContent = "Gerar Vídeo";
  }
}